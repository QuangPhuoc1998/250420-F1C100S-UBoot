/*
 * (C) Copyright 2008
 * Texas Instruments, <www.ti.com>
 * Syed Mohammed Khasim <khasim@ti.com>
 *
 * SPDX-License-Identifier:	GPL-2.0
 */

#ifndef MMC_HOST_DEF_H
#define MMC_HOST_DEF_H

/* Driver definitions */
#define MMCSD_SECTOR_SIZE		512

#endif /* MMC_HOST_DEF_H */
